export const environment = {
  production: true,
  apiKey: 'authorization',
  apiUrl: 'alguna_url',
  apiBase: ''
};

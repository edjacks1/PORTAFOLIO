export const environment = {
  production: false,
  apiKey: 'authorization',
  apiUrl: 'alguna_url',
  apiBase: ''
};

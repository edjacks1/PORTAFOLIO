import { Component } from '@angular/core';
import { TokenService } from './Services/token.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {

  isLogged: boolean;

  constructor(private tokenService: TokenService) {
    if(window.location.pathname === '/login'){
      localStorage.removeItem('token');
      localStorage.removeItem('refresh_token');
      localStorage.removeItem('permissions');
      this.isLogged = false;
    }else{
      if(this.tokenService.getExpirationStatus()){
        this.isLogged = true;
      }else{
        window.location.href = '/login';
        this.isLogged = false;
      }
    }
  }
}

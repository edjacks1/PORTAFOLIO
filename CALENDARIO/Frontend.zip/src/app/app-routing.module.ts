import { NgModule }                  from '@angular/core';
import { Routes, RouterModule }      from '@angular/router';
import { AuthGuard }                 from './Security/auth.guard';
import { PermissionsGuard }          from './Security/permissions.guard';

import { UsersComponent          }   from './Pages/users/users.component';
import { LoginComponent          }   from './Pages/login/login.component';
import { RolesComponent          }   from './Pages/roles/roles.component';
import { PermissionsComponent    }   from './Pages/permissions/permissions.component';
import { OrganizationsComponent  }   from './Pages/organizations/organizations.component';
import { PlacesComponent         }   from './Pages/places/places.component';
import { ResourcesComponent      }   from './Pages/resources/resources.component';
import { HomeComponent           }   from './Pages/home/home.component';
import { ResourcesTypesComponent }   from './Pages/resourcesTypes/resourcesTypes.component';
import { EventsTypesComponent    }   from './Pages/eventsTypes/eventsTypes.component';
import { EventsTagsComponent     }   from './Pages/eventsTags/eventsTags.component';

const routes: Routes = [
  {path: 'login',                component: LoginComponent                                 },
  {path: 'usuarios',             component: UsersComponent,             canActivate:[AuthGuard,PermissionsGuard]},
  {path: 'roles',                component: RolesComponent   ,          canActivate:[AuthGuard,PermissionsGuard]},
  {path: 'permisos',             component: PermissionsComponent,       canActivate:[AuthGuard,PermissionsGuard]},
  {path: 'organizaciones',       component: OrganizationsComponent,     canActivate:[AuthGuard,PermissionsGuard]},
  {path: 'lugares',              component: PlacesComponent,            canActivate:[AuthGuard,PermissionsGuard]},
  {path: 'recursos',             component: ResourcesComponent,         canActivate:[AuthGuard,PermissionsGuard]},
  {path: 'tipo_de_recursos',     component: ResourcesTypesComponent,    canActivate:[AuthGuard,PermissionsGuard]},
  {path: 'tipo_de_evento',       component: EventsTypesComponent,       canActivate:[AuthGuard,PermissionsGuard]},
  {path: 'etiqueta_de_evento',   component: EventsTagsComponent,        canActivate:[AuthGuard,PermissionsGuard]},
  {path: 'inicio',               component: HomeComponent,              canActivate:[AuthGuard]},
  {path: '**',   pathMatch:'full', redirectTo:'inicio', canActivate:[AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

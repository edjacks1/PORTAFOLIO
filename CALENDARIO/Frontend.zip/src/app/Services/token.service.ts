import { Injectable } from '@angular/core';
import * as jwt_decode from 'jwt-decode';

@Injectable({
  providedIn: 'root'
})
export class TokenService {

  token;
  TIMESTAMP = 1000;

  constructor() {
    this.token = localStorage.getItem('token');

    if(this.token === null){
      this.token = false;
    }else{
      this.token = jwt_decode(this.token);
    }
    
  }

  getPermissions(){ 
    return this.token.data;
  }

  getUserId(){
    return this.token.sub;
  }

  getExpirationStatus(){
    let expiresAt   = new Date(this.token.exp * this.TIMESTAMP);
    let createdAt   = new Date(this.token.iat * this.TIMESTAMP);
    let currentDate = new Date();

    if(this.token === false){
      return false;
    }else if((expiresAt > currentDate) && (expiresAt > createdAt)){
      return true;
    }else{
      return false;
    }
  }

}

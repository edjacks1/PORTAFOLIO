import { Injectable    } from '@angular/core';
import { HttpClient    } from '@angular/common/http';
import { Response      } from '../../Interfaces/interfaces';
import { environment   } from '../../../environments/environment';

const API_URL = `${environment.apiUrl}/auth`;

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  login(data){
    return this.http.post<Response>(`${API_URL}/login`,data);
  }

  refreshToken(data){
    return this.http.post<Response>(`${API_URL}/refreshToken`,data);
  }

  validateToken(data){
    return this.http.post<Response>(`${API_URL}/validateToken`,data);
  }

}

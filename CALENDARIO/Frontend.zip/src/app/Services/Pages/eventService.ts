import { Injectable    } from '@angular/core';
import { HttpClient    } from '@angular/common/http';
import { Response      } from '../../Interfaces/interfaces';
import { environment   } from '../../../environments/environment';

const API_URL = `${environment.apiUrl}/event`;

@Injectable({
  providedIn: 'root'
})
export class EventService {

  constructor(private http: HttpClient) { }

  listAll(data){
    return this.http.post<Response>(`${API_URL}/getEvents`,data);
  }

  getById(id){
    return this.http.get<Response>(`${API_URL}/${id}`);
  }

  getResourcesByEventId(id){
    return this.http.get<Response>(`${API_URL}/getResources/${id}`);
  }

  store(data){
    return this.http.post<Response>(API_URL,data);
  }

  update(id,data){
    return this.http.put<Response>(`${API_URL}/${id}`,data);
  }

  destroy(id){
    return this.http.delete<Response>(`${API_URL}/${id}`);
  }

  checkResources(id,data){
    return this.http.put<Response>(`${API_URL}/checkResources/${id}`,data);
  }
  

}

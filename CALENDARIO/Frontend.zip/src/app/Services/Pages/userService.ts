import { Injectable    } from '@angular/core';
import { HttpClient    } from '@angular/common/http';
import { Response      } from '../../Interfaces/interfaces';
import { environment   } from '../../../environments/environment';

const API_URL = `${environment.apiUrl}/user`;

@Injectable({
  providedIn: 'root'
})

export class UserService {

  constructor(private http: HttpClient) { }

  listAll(){
    return this.http.get<Response>(API_URL);
  }

  store(data){
    return this.http.post<Response>(API_URL,data);
  }

  update(id,data){
    return this.http.put<Response>(`${API_URL}/${id}`,data);
  }

  destroy(id){
    return this.http.delete<Response>(`${API_URL}/${id}`);
  }

  assignRoles(id,data){
    return this.http.put<Response>(`${API_URL}/assignRole/${id}`,data);
  }

  checkEmail(data){
    return this.http.post<Response>(`${API_URL}/checkEmail`,data);
  }
}

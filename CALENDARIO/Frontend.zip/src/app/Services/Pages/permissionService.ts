import { Injectable    } from '@angular/core';
import { HttpClient    } from '@angular/common/http';
import { Response      } from '../../Interfaces/interfaces';
import { environment   } from '../../../environments/environment';

const API_URL = `${environment.apiUrl}/permission`;

@Injectable({
  providedIn: 'root'
})
export class PermissionService {

  constructor(private http: HttpClient) { }

  listAll(){
    return this.http.get<Response>(API_URL);
  }

}

import { Injectable    } from '@angular/core';
import { HttpClient    } from '@angular/common/http';
import { Response      } from '../../Interfaces/interfaces';
import { environment   } from '../../../environments/environment';

const API_URL = `${environment.apiUrl}/role`;

@Injectable({
  providedIn: 'root'
})
export class RoleService {

  constructor(private http: HttpClient) { }

  listAll(){
    return this.http.get<Response>(API_URL);
  }

  store(data){
    return this.http.post<Response>(API_URL,data);
  }

  update(id,data){
    return this.http.put<Response>(`${API_URL}/${id}`,data);
  }

  destroy(id){
    return this.http.delete<Response>(`${API_URL}/${id}`);
  }

  assignPermissions(id,data){
    return this.http.put<Response>(`${API_URL}/assignPermission/${id}`,data);
  }

}

import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

import {FormControl, Validators, FormGroup} from '@angular/forms';
import { map } from 'rxjs/operators';
import { FormCustomErrorState } from '../../../../Components/formGroup/formCustomErrorState';
import { ResourceTypeService } from '../../../../Services/Pages/resourceTypeService';


@Component({
  templateUrl: './general.component.html'
})
export class ResourceGeneralFormComponent {
  resourceForm: FormGroup;
  resourcesTypes;

  constructor(private dialogRef: MatDialogRef<ResourceGeneralFormComponent>,@Inject(MAT_DIALOG_DATA) private data,private resourceTypeService: ResourceTypeService) {
    this.listResourcesType();
    this.resourceForm = new FormGroup({
      'name'              : new FormControl(data.name,                 [Validators.required, Validators.maxLength(45)]),
      'description'       : new FormControl(data.description,          [Validators.required]),
      'owner'             : new FormControl(data.owner,                [Validators.required]),
      'patrimonial_id'    : new FormControl(data.patrimonial_id,       [Validators.required, Validators.maxLength(45)]),
      'type_id'           : new FormControl(data.type_id,              [Validators.required]),
      'remark'            : new FormControl(data.remark,               [Validators.required]),
    });
  }

  listResourcesType(){
    this.resourcesTypes = this.resourceTypeService.listAll().pipe(map(data => { return data.data}));
  }

  matcher = new FormCustomErrorState();

  validate(){
    let resource = {
      name                : this.resourceForm.controls.name.value,
      description         : this.resourceForm.controls.description.value,
      owner               : this.resourceForm.controls.owner.value,
      patrimonial_id      : this.resourceForm.controls.patrimonial_id.value,
      type_id             : this.resourceForm.controls.type_id.value,
      remark              : this.resourceForm.controls.remark.value,
      submitted           : true,
    };
    this.dialogRef.close(resource);
  }
}

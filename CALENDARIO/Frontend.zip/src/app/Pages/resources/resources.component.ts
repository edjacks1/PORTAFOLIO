import { Component, ChangeDetectorRef, ViewChild } from '@angular/core';
//Material
import {MatPaginator      } from '@angular/material/paginator';
import {MatSort           } from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {MatDialog         } from '@angular/material/dialog';
//FormComponents
import { ResourceGeneralFormComponent } from './forms/general/general.component';
//Services
import { TokenService    } from '../../Services/token.service';
import { ResourceService } from '../../Services/Pages/resourceService';
import { ToastrService   } from 'ngx-toastr';
//Configurations
import { toaster } from '../../Configurations/toaster';
import { Resource } from '../../Interfaces/interfaces';


const TOASTER_OPTIONS = toaster;
const DIALOG_SIZE     = '500px';

@Component({templateUrl: './resources.component.html'})
export class ResourcesComponent {
  displayedColumns: string[] = ['id', 'name', 'description', 'owner', 'patrimonial_id', 'type_id', 'remark', 'options'];
  dataSource;

  currentUserPermissions:any;
  currentModulePermissions:any;

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  filterMatTableData(evento: Event) {
    const FILTER_VALUE = (evento.target as HTMLInputElement).value;
    this.dataSource.filter = FILTER_VALUE.trim().toLowerCase();
  }
  constructor(
                private chRef: ChangeDetectorRef,
                private tokenService: TokenService,
                private resourceService: ResourceService, 
                private dialog: MatDialog,
                private toastr: ToastrService
              ){ 
    this.listResources();
    this.userCan();
  }
  userCan(){
    this.currentUserPermissions   = this.tokenService.getPermissions();
    this.currentModulePermissions = {
      create_class : this.currentUserPermissions.includes("create_resource") ? '' : 'hidden' , 
      edit_class   : this.currentUserPermissions.includes("edit_resource")   ? '' : 'hidden' , 
      delete_class : this.currentUserPermissions.includes("delete_resource") ? '' : 'hidden' , 
      has_options  : (this.currentUserPermissions.includes("edit_resource") || this.currentUserPermissions.includes("delete_resource")) ? '' : 'hidden'
    }
  }
  listResources(){
    this.resourceService.listAll().subscribe(resp => { 
      this.dataSource           = new MatTableDataSource<Resource>(resp.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort      = this.sort;
      this.chRef.detectChanges();
    });
  }
  addResource(resource = null){
    if(this.currentUserPermissions.includes("create_resource")){
      let dialogRef = this.dialog.open(ResourceGeneralFormComponent,{data: resource === null ? '' : resource});
      dialogRef.afterClosed().subscribe((result: Resource) => {
        if(result['submitted']){
          this.resourceService.store(result).subscribe(
            resp =>{
              this.listResources();
              this.toastr.success(`Se ha creado el recurso ${result.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.addResource(result); }
          );
        }
      });
    }
  }
  editResource(resource){
    if(this.currentUserPermissions.includes("edit_resource")){
      let dialogRef = this.dialog.open(ResourceGeneralFormComponent,{data: resource === null ? '' : resource});
      dialogRef.afterClosed().subscribe((result: Resource) => {
        if(result['submitted']){
          this.resourceService.update(resource.id,result).subscribe(
            resp =>{
              this.listResources();
              this.toastr.success(`Se ha editado el recurso ${result.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.addResource(result); }
          );
        }
      });
    }
  }
  deleteResource(resource){
    if(this.currentUserPermissions.includes("delete_resource")){
      this.resourceService.destroy(resource.id).subscribe(resp => {
        this.listResources();
        this.toastr.success(`Se ha eliminado el recurso ${resource.name}`, 'Exito',TOASTER_OPTIONS);
      })
    }
  }
}

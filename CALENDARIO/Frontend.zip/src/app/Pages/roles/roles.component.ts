import { Component, ChangeDetectorRef, ViewChild } from '@angular/core';
//Material
import {MatPaginator      } from '@angular/material/paginator';
import {MatSort           } from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {MatDialog         } from '@angular/material/dialog';
//FormComponents
import { RoleGeneralFormComponent             } from './forms/general/general.component';
import { RoleAssignPermissionsFormComponent   } from './forms/assignPermissions/assignPermissions.component';
import { RoleShowAssignedPermissionsComponent } from './show/assignedPermissions/assignedPermissions.component';
//Services
import { TokenService  } from '../../Services/token.service';
import { RoleService   } from '../../Services/Pages/roleService';
import { ToastrService } from 'ngx-toastr';
//Interfaces
import { Role } from '../../Interfaces/interfaces';
//Configurations
import { toaster } from '../../Configurations/toaster';

const TOASTER_OPTIONS = toaster;
const DIALOG_SIZE     = '400px';

@Component({
  templateUrl: './roles.component.html'
})
export class RolesComponent {

  displayedColumns: string[] = ['role_id', 'name', 'description','options'];
  dataSource;

  currentUserPermissions: any;
  currentModulePermissions:any;

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  constructor(
                private roleService: RoleService, 
                private chRef: ChangeDetectorRef, 
                private tokenService: TokenService,
                private dialog: MatDialog,
                private toastr: ToastrService
              ){
    this.listRoles();
    this.userCan();
  }
  userCan(){
    this.currentUserPermissions   = this.tokenService.getPermissions();
    this.currentModulePermissions = {
      create_class : this.currentUserPermissions.includes("create_role") ? '' : 'hidden' , 
      edit_class   : this.currentUserPermissions.includes("edit_role")   ? '' : 'hidden' , 
      delete_class : this.currentUserPermissions.includes("delete_role") ? '' : 'hidden' , 
    }
  }
  filterMatTableData(evento: Event) {
    const FILTER_VALUE = (evento.target as HTMLInputElement).value;
    this.dataSource.filter = FILTER_VALUE.trim().toLowerCase();
  }

  listRoles(){
    this.roleService.listAll().subscribe(resp => { 
      this.dataSource           = new MatTableDataSource<Role>(resp.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort      = this.sort;
      this.chRef.detectChanges();
    });
  }



  addRole(role = null){
    if(this.currentUserPermissions.includes("create_role")){
      let dialogRef = this.dialog.open(RoleGeneralFormComponent,{data: role === null ? '' : role, width: DIALOG_SIZE});
      dialogRef.afterClosed().subscribe((result:Role) => {
        if(result['submitted']){
          this.roleService.store(result).subscribe(
            resp =>{
              this.listRoles();
              this.toastr.success(`Se ha creado el role ${result.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.addRole(result); }
          );
        }
      });
    }
  }

  editRole(role){
    if(this.currentUserPermissions.includes("edit_role")){
      let dialogRef = this.dialog.open(RoleGeneralFormComponent,{data: role, width: DIALOG_SIZE});
      dialogRef.afterClosed().subscribe((result:Role) => {
        if(result['submitted']){
          this.roleService.update(role.role_id,result).subscribe(
            resp =>{
              this.listRoles();
              this.toastr.success(`Se ha editado el role ${result.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.editRole(result); }
          );
        }
      });
    } 
  }

  deleteRole(role){
    if(this.currentUserPermissions.includes("delete_role")){
      this.roleService.destroy(role.role_id).subscribe(resp => {
        this.listRoles();
        this.toastr.success(`Se ha eliminado el rol ${role.name}`, 'Exito',TOASTER_OPTIONS);
      })
    }
  }

  assignPermissions(role){
    if(this.currentUserPermissions.includes("edit_role")){
      let dialogRef = this.dialog.open(RoleAssignPermissionsFormComponent,{data: role.permissions, width: DIALOG_SIZE});
      dialogRef.afterClosed().subscribe((result:Role) => {
        if(result['submitted']){
          this.roleService.assignPermissions(role.role_id,result).subscribe(
            resp =>{
              this.listRoles();
              this.toastr.success(`Se han asignado permisos al rol ${role.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.assignPermissions(result); }
          );
        }
      });
    }
  }

  showAssignedPermissions(role){
    this.dialog.open(RoleShowAssignedPermissionsComponent,{data: role.permissions, width: DIALOG_SIZE});
  }
}

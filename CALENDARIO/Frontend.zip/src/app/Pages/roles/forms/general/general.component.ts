import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

import {FormControl,  Validators, FormGroup} from '@angular/forms';
import { FormCustomErrorState } from '../../../../Components/formGroup/formCustomErrorState';

@Component({
  templateUrl: './general.component.html'
})
export class RoleGeneralFormComponent{

  rolForm: FormGroup;

  constructor(private dialogRef: MatDialogRef<RoleGeneralFormComponent>,@Inject(MAT_DIALOG_DATA) private data) {
    this.rolForm = new FormGroup({
      'name'              : new FormControl(data.name,                 [Validators.required]),
      'description'       : new FormControl(data.description,          [Validators.required]),
    });
  }

  matcher = new FormCustomErrorState();


  validar(){
    let rol = {
      name                : this.rolForm.controls.name.value,
      description         : this.rolForm.controls.description.value,
      submitted           : true,
    };

    this.dialogRef.close(rol);
  }

}

import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

import {FormControl,Validators, FormGroup} from '@angular/forms';
import { map } from 'rxjs/operators';
import { FormCustomErrorState } from '../../../../Components/formGroup/formCustomErrorState';
import { PermissionService } from '../../../../Services/Pages/permissionService';



@Component({
  templateUrl: './assignPermissions.component.html'
})
export class RoleAssignPermissionsFormComponent {

  permissions: any;
  roleHaspermissions = [];
  rolForm: FormGroup;

  constructor(private dialogRef: MatDialogRef<RoleAssignPermissionsFormComponent>,@Inject(MAT_DIALOG_DATA) private data, private permissionService: PermissionService) {
    this.listPermissions();
    this.assignedPermissions();

    this.rolForm = new FormGroup({
      'permissions'     : new FormControl(this.roleHaspermissions,     [Validators.required]),
    });

  }

  matcher = new FormCustomErrorState();

  validate(){
    let user = {
      permissions    : this.rolForm.controls.permissions.value,
      submitted: true
    };
    this.dialogRef.close(user);
  }

  listPermissions(){
    this.permissions = this.permissionService.listAll().pipe(map(data => { return data.data}));
  }

  assignedPermissions(){
    this.data.forEach(element => {
      this.roleHaspermissions.push(element.permission_id);
    });
  }
}

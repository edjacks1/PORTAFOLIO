import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

import {FormControl, Validators, FormGroup} from '@angular/forms';
import { FormCustomErrorState } from '../../../../Components/formGroup/formCustomErrorState';

@Component({
  templateUrl: './general.component.html'
})
export class EventTagGeneralFormComponent{

  eventTagForm: FormGroup;

  constructor(private dialogRef: MatDialogRef<EventTagGeneralFormComponent>,@Inject(MAT_DIALOG_DATA) private data) {
    this.eventTagForm = new FormGroup({
      'name'              : new FormControl(data.name,           [Validators.required]),
      'color'             : new FormControl(data.color,          [Validators.required]),
    });
  }

  matcher = new FormCustomErrorState();


  validate(){
    let eventTag = {
      name                : this.eventTagForm.controls.name.value,
      color               : this.eventTagForm.controls.color.value,
      submitted           : true,
    };
    this.dialogRef.close(eventTag);
  }

}

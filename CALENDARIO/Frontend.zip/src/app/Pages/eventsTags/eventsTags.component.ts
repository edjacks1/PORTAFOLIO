import { Component, ChangeDetectorRef, ViewChild } from '@angular/core';
//Material
import {MatPaginator      } from '@angular/material/paginator';
import {MatSort           } from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {MatDialog         } from '@angular/material/dialog';
//FormComponents
import { EventTagGeneralFormComponent } from './forms/general/general.component';
//Services
import { TokenService } from '../../Services/token.service';
import { EventTagService } from '../../Services/Pages/eventTagService';
import { ToastrService} from 'ngx-toastr';
//Interfaces
// import  from '../../Interfaces/interfaces';
//Configurations
import { toaster } from '../../Configurations/toaster';
import { EventTag } from '../../Interfaces/interfaces';

const TOASTER_OPTIONS = toaster;
const DIALOG_SIZE     = '500px';

@Component({templateUrl: './eventsTags.component.html'})

export class EventsTagsComponent{
  displayedColumns: string[] = ['id', 'name', 'color','options'];
  dataSource;

  currentUserPermissions:any;
  currentModulePermissions:any;
  
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  filterMatTableData(evento: Event) {
    const FILTER_VALUE = (evento.target as HTMLInputElement).value;
    this.dataSource.filter = FILTER_VALUE.trim().toLowerCase();
  }
  constructor(
                private chRef: ChangeDetectorRef, 
                private tokenService: TokenService,
                private eventTagService: EventTagService, 
                private dialog: MatDialog,
                private toastr: ToastrService
              ){
    this.listEType();
    this.userCan();
  }
  userCan(){
    this.currentUserPermissions   = this.tokenService.getPermissions();
    this.currentModulePermissions = {
      create_class : this.currentUserPermissions.includes("create_eventTag") ? '' : 'hidden' , 
      edit_class   : this.currentUserPermissions.includes("edit_eventTag")   ? '' : 'hidden' , 
      delete_class : this.currentUserPermissions.includes("delete_eventTag") ? '' : 'hidden' , 
      has_options  : (this.currentUserPermissions.includes("edit_eventTag") || this.currentUserPermissions.includes("delete_eventTag")) ? '' : 'hidden'
    }
  }
  listEType(){
    this.eventTagService.listAll().subscribe(resp => { 
      this.dataSource           = new MatTableDataSource<EventTag>(resp.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort      = this.sort;
      this.chRef.detectChanges();
    });
  }
  addETag(eventTag = null){
    if(this.currentUserPermissions.includes("create_eventTag")){
      let dialogRef = this.dialog.open(EventTagGeneralFormComponent,{data: eventTag === null ? '' : eventTag, width: DIALOG_SIZE});
      dialogRef.afterClosed().subscribe((result:EventTag) => {
        if(result['submitted']){
          this.eventTagService.store(result).subscribe(
            resp =>{
              this.listEType();
              this.toastr.success(`Se ha creado la etiqueta de evento ${result.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.addETag(result); }
          );
        }
      });
    }
  }
  editETag(eventTag){
    if(this.currentUserPermissions.includes("edit_eventTag")){
      let dialogRef = this.dialog.open(EventTagGeneralFormComponent,{data: eventTag, width: DIALOG_SIZE});
      dialogRef.afterClosed().subscribe((result:EventTag) => {
        if(result['submitted']){
          this.eventTagService.update(eventTag.id,result).subscribe(
            resp =>{
              this.listEType();
              this.toastr.success(`Se ha editado la etiqueta de evento ${eventTag.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.editETag(result); }
          );
        }
      });
    } 
  }
  deleteETag(eventTag){
    if(this.currentUserPermissions.includes("delete_eventTag")){
      this.eventTagService.destroy(eventTag.id).subscribe(resp => {
        this.listEType();
        this.toastr.success(`Se ha eliminado la etiqueta de evento ${eventTag.name}`, 'Exito',TOASTER_OPTIONS);
      })
    }
  }
}

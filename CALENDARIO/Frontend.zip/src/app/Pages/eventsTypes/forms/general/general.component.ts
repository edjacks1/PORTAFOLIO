import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

import {FormControl, Validators, FormGroup} from '@angular/forms';
import { FormCustomErrorState } from '../../../../Components/formGroup/formCustomErrorState';

@Component({
  templateUrl: './general.component.html'
})
export class EventTypeGeneralFormComponent{

  eventTypeForm: FormGroup;

  constructor(private dialogRef: MatDialogRef<EventTypeGeneralFormComponent>,@Inject(MAT_DIALOG_DATA) private data) {
    this.eventTypeForm = new FormGroup({
      'name'              : new FormControl(data.name,                 [Validators.required]),
      'description'       : new FormControl(data.description,          [Validators.required]),
    });
  }

  matcher = new FormCustomErrorState();


  validar(){
    let resourceEvent = {
      name                : this.eventTypeForm.controls.name.value,
      description         : this.eventTypeForm.controls.description.value,
      submitted           : true,
    };

    this.dialogRef.close(resourceEvent);
  }

}

import { Component, ChangeDetectorRef, ViewChild } from '@angular/core';
//Material
import {MatPaginator      } from '@angular/material/paginator';
import {MatSort           } from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {MatDialog         } from '@angular/material/dialog';
//FormComponents
import { EventTypeGeneralFormComponent } from './forms/general/general.component';
//Services
import { TokenService     } from '../../Services/token.service';
import { EventTypeService } from '../../Services/Pages/eventTypeService';
import { ToastrService    } from 'ngx-toastr';
//Interfaces
import { EventType } from '../../Interfaces/interfaces';
//Configurations
import { toaster } from '../../Configurations/toaster';



const TOASTER_OPTIONS = toaster;
const DIALOG_SIZE     = '500px';

@Component({templateUrl: './eventsTypes.component.html'})

export class EventsTypesComponent{
  displayedColumns: string[] = ['id', 'name', 'description','options'];
  dataSource;

  currentUserPermissions:any;
  currentModulePermissions:any;

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  filterMatTableData(evento: Event) {
    const FILTER_VALUE = (evento.target as HTMLInputElement).value;
    this.dataSource.filter = FILTER_VALUE.trim().toLowerCase();
  }
  constructor(
                private chRef: ChangeDetectorRef, 
                private tokenService: TokenService,
                private eventTypeService: EventTypeService, 
                private dialog: MatDialog,
                private toastr: ToastrService
              ){
    this.listEType();
    this.userCan();
  }
  userCan(){
    this.currentUserPermissions   = this.tokenService.getPermissions();
    this.currentModulePermissions = {
      create_class : this.currentUserPermissions.includes("create_eventType") ? '' : 'hidden' , 
      edit_class   : this.currentUserPermissions.includes("edit_eventType")   ? '' : 'hidden' , 
      delete_class : this.currentUserPermissions.includes("delete_eventType") ? '' : 'hidden' , 
      has_options  : (this.currentUserPermissions.includes("edit_eventType") || this.currentUserPermissions.includes("delete_eventType")) ? '' : 'hidden'
    }
  }
  listEType(){
    this.eventTypeService.listAll().subscribe(resp => { 
      this.dataSource           = new MatTableDataSource<EventType>(resp.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort      = this.sort;
      this.chRef.detectChanges();
    });
  }
  addEType(eventType = null){
    if(this.currentUserPermissions.includes("create_eventType")){
      let dialogRef = this.dialog.open(EventTypeGeneralFormComponent,{data: eventType === null ? '' : eventType, width: DIALOG_SIZE});
      dialogRef.afterClosed().subscribe((result:EventType) => {
        if(result['submitted']){
          this.eventTypeService.store(result).subscribe(
            resp =>{
              this.listEType();
              this.toastr.success(`Se ha creado el tipo de evento ${result.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.addEType(result); }
          );
        }
      });
    }
  }
  editEType(eventType){
    if(this.currentUserPermissions.includes("edit_eventType")){
      let dialogRef = this.dialog.open(EventTypeGeneralFormComponent,{data: eventType, width: DIALOG_SIZE});
      dialogRef.afterClosed().subscribe((result:EventType) => {
        if(result['submitted']){
          this.eventTypeService.update(eventType.id,result).subscribe(
            resp =>{
              this.listEType();
              this.toastr.success(`Se ha editado el tipo de evento ${eventType.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.editEType(result); }
          );
        }
      });
    }
  }

  deleteEType(eventType){
    if(this.currentUserPermissions.includes("delete_eventType")){
      this.eventTypeService.destroy(eventType.id).subscribe(resp => {
        this.listEType();
        this.toastr.success(`Se ha eliminado el tipo de evento ${eventType.name}`, 'Exito',TOASTER_OPTIONS);
      })
    }
  }

}

import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  templateUrl: './assignedRoles.component.html'
})
export class UserShowAssignedRolesComponent{

  assignedRoles;

  constructor(private dialogRef: MatDialogRef<UserShowAssignedRolesComponent>,@Inject(MAT_DIALOG_DATA) private data) {
    this.assignedRoles = this.data;
  }

}

import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {FormControl,Validators, FormGroup} from '@angular/forms';
import { FormCustomErrorState } from '../../../../Components/formGroup/formCustomErrorState';
import { OrganizationService } from '../../../../Services/Pages/organizationService';
import { map } from 'rxjs/operators';


@Component({
  templateUrl: './general.component.html'
})
export class UserGeneralFormComponent {
  userForm: FormGroup;
  organizations:any;

  constructor(
                private dialogRef: MatDialogRef<UserGeneralFormComponent>,@Inject(MAT_DIALOG_DATA) 
                public data, 
                private organizationService: OrganizationService,
              ){
    this.listOrganizations();
    this.userForm = new FormGroup({
      'name'              : new FormControl(data.name,                 [Validators.required, Validators.maxLength(45)]),
      'second_name'       : new FormControl(data.second_name,          [Validators.required, Validators.maxLength(45)]),
      'last_name'         : new FormControl(data.last_name,            [Validators.required, Validators.maxLength(45)]),
      'maternal_surname'  : new FormControl(data.maternal_surname,     [Validators.required, Validators.maxLength(45)]),
      'phone'             : new FormControl(data.phone,                [Validators.required]),
      'email'             : new FormControl(data.email,                [Validators.required,Validators.email]),
      'organization_id'   : new FormControl(data.organization_id,      [Validators.required]),
      'password'          : new FormControl(null, [Validators.required ,Validators.minLength(8),this.validatePassword]),
    });
  }

  matcher = new FormCustomErrorState();

  listOrganizations(){
    this.organizations = this.organizationService.listAll().pipe(map(data => {return data.data}));
  }

  validate(){
    let user = {
      name                : this.userForm.controls.name.value,
      second_name         : this.userForm.controls.second_name.value,
      last_name           : this.userForm.controls.last_name.value,
      maternal_surname    : this.userForm.controls.maternal_surname.value,
      phone               : this.userForm.controls.phone.value,
      email               : this.userForm.controls.email.value,
      organization_id     : this.userForm.controls.organization_id.value,
      password            : this.userForm.controls.password.value,
      submitted           : true,
    };
    
    this.dialogRef.close(user);
  }

  validatePassword(c: FormControl) {
    let REG_LOWER_CASE         = /[a-z]/g; 
    let REG_UPPER_CASE         = /[A-Z]/g; 
    let REG_DIGIT              = /[0-9]/g; 
    let REG_SPECIAL_CHARACTER  = /[@$!%*#?&]/g; 

    if(! REG_LOWER_CASE.test(c.value)){
      return {validatePasswordLowerCase: {valid: false}};
    }
    else if(! REG_UPPER_CASE.test(c.value) ){
      return {validatePasswordUpperCase: {valid: false}};
    }
    else if(! REG_DIGIT.test(c.value)){
      return {validatePasswordDigit: {valid: false}};
    }
    else if(! REG_SPECIAL_CHARACTER.test(c.value)){
      return {validatePassworSpecialCharacter: {valid: false}};
    }
  }
}

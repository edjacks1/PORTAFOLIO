import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {FormControl,Validators, FormGroup} from '@angular/forms';
import { FormCustomErrorState } from '../../../../Components/formGroup/formCustomErrorState';
import { RoleService } from '../../../../Services/Pages/roleService';
import { map } from 'rxjs/operators';


@Component({
  templateUrl: './assignRoles.component.html'
})
export class UserAssignRolesFormComponent {

  roles: any;
  userHasRoles = [];
  userForm: FormGroup;

  constructor(private dialogRef: MatDialogRef<UserAssignRolesFormComponent>,@Inject(MAT_DIALOG_DATA) private data, private roleService: RoleService) {
    this.listRoles();
    this.rolesAssigned();
    this.userForm = new FormGroup({
      'roles'     : new FormControl(this.userHasRoles,     [Validators.required]),
    });
  }

  matcher = new FormCustomErrorState();

  validate(){
    let user = {
      roles    : this.userForm.controls.roles.value,
      submitted: true
    };
    this.dialogRef.close(user);
  }
  listRoles(){
    this.roles = this.roleService.listAll().pipe(map(data => { return data.data}));
  }
  rolesAssigned(){
    this.data.forEach(element => {
      this.userHasRoles.push(element.role_id);
    });
  }
}

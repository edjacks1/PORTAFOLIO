import { Component, ChangeDetectorRef, ViewChild } from '@angular/core';
//Material
import {MatPaginator      } from '@angular/material/paginator';
import {MatSort           } from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {MatDialog         } from '@angular/material/dialog';
//FormComponents
import { UserGeneralFormComponent       } from './forms/general/general.component';
import { UserAssignRolesFormComponent   } from './forms/assignRoles/assignRoles.component';
import { UserShowAssignedRolesComponent } from './show/roles/assignedRoles.component';
//Services
import { TokenService } from '../../Services/token.service';
import { UserService  } from '../../Services/Pages/userService';
import { ToastrService} from 'ngx-toastr';
//Interfaces
import { User, Role } from '../../Interfaces/interfaces';
//Configurations
import { toaster } from '../../Configurations/toaster';

const TOASTER_OPTIONS = toaster;
const DIALOG_SIZE     = '500px';

@Component({
  selector: 'dashboard-usuarios',
  templateUrl: './users.component.html'
})

export class UsersComponent {
  dataSource;
  displayedColumns: string[] = [
    'id', 
    'name', 
    'completeName', 
    'second_name', 
    'last_name', 
    'maternal_surname', 
    'organization.abbreviation',
    'phone',
    'email', 
    'options'
  ];
  
  currentUserPermissions;
  currentUserId;
  currentModulePermissions;

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  filterMatTableData(evento: Event) {
    const FILTER_VALUE = (evento.target as HTMLInputElement).value;
    this.dataSource.filter = FILTER_VALUE.trim().toLowerCase();
  }
  constructor(
                private chRef: ChangeDetectorRef, 
                private tokenService: TokenService, 
                private userService: UserService, 
                private dialog: MatDialog,
                private toastr: ToastrService
              ){
    this.currentUserId  = this.tokenService.getUserId();
    this.listUsers();
    this.userCan();
  }
  userCan(){
    this.currentUserPermissions   = this.tokenService.getPermissions();
    this.currentModulePermissions = {
      create_class : this.currentUserPermissions.includes("create_user") ? '' : 'hidden' , 
      edit_class   : this.currentUserPermissions.includes("edit_user")   ? '' : 'hidden' , 
      delete_class : this.currentUserPermissions.includes("delete_user") ? '' : 'hidden' , 
    }
  }
  listUsers(){
    this.userService.listAll().subscribe(resp => { 
      this.dataSource           = new MatTableDataSource<User>(resp.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort      = this.sort;
      this.chRef.detectChanges();
    });
  }
  addUser(user = null){
    if(this.currentUserPermissions.includes("create_user")){
      let dialogRef = this.dialog.open(UserGeneralFormComponent,{data: user === null ? '' : user});
      dialogRef.afterClosed().subscribe((result:User) => {
        if(result['submitted']){
          this.userService.store(result).subscribe(
            resp =>{
              this.listUsers();
              this.toastr.success(`Se ha creado el usuario ${result.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.addUser(result); }
          );
        }
      });
    }
  }
  editUser(user){
    if(this.currentUserPermissions.includes("edit_user")){
      let dialogRef = this.dialog.open(UserGeneralFormComponent,{data: user});
      dialogRef.afterClosed().subscribe((result:User) => {
        if(result['submitted']){
          this.userService.update(user.id,result).subscribe(
            resp =>{
              this.listUsers();
              this.toastr.success(`Se ha editado el usuario ${user.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.editUser(result); }
          );
        }
      });
    }
  }
  deleteUser(user){
    if(this.currentUserPermissions.includes("delete_user")){
      this.userService.destroy(user.id).subscribe(resp => {
        this.listUsers();
        this.toastr.success(`Se ha eliminado el usuario ${user.name}`, 'Exito',TOASTER_OPTIONS);
      })
    }
  }
  assignRoles(user){
    if(this.currentUserPermissions.includes("edit_user")){
      let dialogRef = this.dialog.open(UserAssignRolesFormComponent,{data: user.roles, width: DIALOG_SIZE});
      dialogRef.afterClosed().subscribe((result:Role) => {
        if(result['submitted']){
          this.userService.assignRoles(user.id,result).subscribe(
            resp =>{
              this.listUsers();
              this.toastr.success(`Se han asignado roles al usuario ${user.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.assignRoles(result); }
          );
        }
      });
    }
  }
  showAssignedRoles(user){
    this.dialog.open(UserShowAssignedRolesComponent,{data: user.roles, width: DIALOG_SIZE});
  }
}

import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

import {FormControl,Validators, FormGroup} from '@angular/forms';
import { FormCustomErrorState } from '../../../../Components/formGroup/formCustomErrorState';
import { PlaceService } from '../../../../Services/Pages/placeService';
import { map } from 'rxjs/operators';

@Component({
  templateUrl: './assignPlaces.component.html'
})
export class OrganizationAssignPlacesFormComponent {

  places: any;
  organizationHasPlaces = [];
  organizationForm: FormGroup;

  constructor(private dialogRef: MatDialogRef<OrganizationAssignPlacesFormComponent>,@Inject(MAT_DIALOG_DATA) private data, private placeService: PlaceService) {
    this.listPlaces();
    this.placesAssigned();
    this.organizationForm = new FormGroup({
      'places'     : new FormControl(this.organizationHasPlaces,     [Validators.required]),
    });
  }

  matcher = new FormCustomErrorState();

  validate(){
    let organization = {
      places    : this.organizationForm.controls.places.value,
      submitted: true
    };
    this.dialogRef.close(organization);
  }
  listPlaces(){
    this.places = this.placeService.listAll().pipe(map(resp => {return resp.data}));
  }
  placesAssigned(){
    this.data.forEach(element => {
      this.organizationHasPlaces.push(element.id);
    });
  }
}

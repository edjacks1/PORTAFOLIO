import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

import {FormControl,Validators, FormGroup} from '@angular/forms';
import { FormCustomErrorState } from '../../../../Components/formGroup/formCustomErrorState';


@Component({
  templateUrl: './general.component.html'
})
export class OrganizationGeneralFormComponent {
  organizationForm: FormGroup;

  constructor(private dialogRef: MatDialogRef<OrganizationGeneralFormComponent>,@Inject(MAT_DIALOG_DATA) private data) {
    this.organizationForm = new FormGroup({
      'abbreviation'      : new FormControl(data.abbreviation,  [Validators.required]),
      'name'              : new FormControl(data.name,          [Validators.required]),
      'phone'             : new FormControl(data.phone,         [Validators.required]),
      'email'             : new FormControl(data.email,         [Validators.required,Validators.email]),
      'x'                 : new FormControl(100,             [Validators.required]),
      'y'                 : new FormControl(100,             [Validators.required]),
    });
  }

  matcher = new FormCustomErrorState();

  validate(){
    let organization = {
      name            : this.organizationForm.controls.name.value,
      abbreviation    : this.organizationForm.controls.abbreviation.value,
      email           : this.organizationForm.controls.email.value,
      phone           : this.organizationForm.controls.phone.value,
      x               : this.organizationForm.controls.x.value,
      y               : this.organizationForm.controls.y.value,
      submitted       : true
    };

    this.dialogRef.close(organization);
  }

}

import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  templateUrl: './assignedPlaces.component.html'
})
export class OrganizationShowAssignedPlacesComponent{

  assignedPlaces;

  constructor(private dialogRef: MatDialogRef<OrganizationShowAssignedPlacesComponent>,@Inject(MAT_DIALOG_DATA) private data) {
    this.assignedPlaces = this.data;
  }

}

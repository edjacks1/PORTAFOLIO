import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

import { FormControl, Validators, FormGroup } from '@angular/forms';
import { map } from 'rxjs/operators';
import { DatePipe } from '@angular/common';
import { FormCustomErrorState } from '../../../../Components/formGroup/formCustomErrorState';
import { PlaceService } from '../../../../Services/Pages/placeService';
import { UserService } from '../../../../Services/Pages/userService';
import { EventTagService } from 'src/app/Services/Pages/eventTagService';
import { EventTypeService } from 'src/app/Services/Pages/eventTypeService';
import { ResourceService } from 'src/app/Services/Pages/resourceService';


@Component({
  templateUrl: './general.component.html',
  providers: [DatePipe]
})
export class EventGeneralFormComponent {
  eventForm: FormGroup;

  places;
  users;
  eventTypes;
  eventTags;
  resourcesList;

  guests     = [];
  organizers = [];
  resources  = [];

  constructor(
                private dialogRef: MatDialogRef<EventGeneralFormComponent>,@Inject(MAT_DIALOG_DATA) public data, 
                private datePipe: DatePipe,
                private placeService: PlaceService,
                private userService: UserService,
                private eventTagService: EventTagService,
                private eventTypeService: EventTypeService,
                private resourceService: ResourceService
              ) {
    this.listPlaces();
    this.listUsers();
    this.listEventTypes();
    this.listEventTags();
    this.listResources();

    let start_date = (data.start_at == null) ? null : new Date(data.start_at);
    let end_at     = (data.end_at == null)   ? null : new Date(data.end_at);
     
    this.eventForm = new FormGroup({
      'name'            : new FormControl(data.name,                 [Validators.required, Validators.maxLength(50)]),
      'description'     : new FormControl(data.description,          [Validators.required, Validators.maxLength(150)]),
      'place_id'        : new FormControl(data.place_id,             [Validators.required]),
      'created_by'      : new FormControl(data.created_by,           [Validators.required]),
      'type'            : new FormControl(data.type,                 [Validators.required]),
      'tag'             : new FormControl(data.tag,                  [Validators.required]),
      'organizers'      : new FormControl(this.organizers,           [Validators.required]),
      'guests'          : new FormControl(this.guests,               [Validators.required]),
      'resources'       : new FormControl(this.resources,            [Validators.required]),

      'start_at'        : new FormControl(start_date,                                      [Validators.required, this.validateStartDate]),
      'end_at'          : new FormControl(end_at,                                          [Validators.required, this.validateEndDate]),
      'start_at_time'   : new FormControl(this.datePipe.transform(data.start_at, 'HH:mm'), [Validators.required, this.validateStartDateTime]),
      'end_at_time'     : new FormControl(this.datePipe.transform(data.end_at,   'HH:mm'), [Validators.required, this.validateEndDateTime]),
    });
  }

  matcher = new FormCustomErrorState();

  listPlaces(){
    this.places = this.placeService.listAll().pipe(map(data => { return data.data}));
  }

  listUsers(){
    this.users = this.userService.listAll().pipe(map(data => { return data.data}));
  }

  listEventTypes(){
    this.eventTypes = this.eventTypeService.listAll().pipe(map(data => { return data.data}));
  }

  listEventTags(){
    this.eventTags = this.eventTagService.listAll().pipe(map(data => { return data.data}));
  }

  listResources(){
    this.resourcesList = this.resourceService.listAll().pipe(map(data => { return data.data}));
  }

  validate(){
    let startTime = (this.eventForm.controls.start_at_time.value).split(':');
    let endTime   = (this.eventForm.controls.end_at_time.value).split(':');
    let startDate = this.eventForm.controls.start_at.value;
    let endDate   = this.eventForm.controls.end_at.value;

    startDate.setHours(startTime[0]);
    startDate.setMinutes(startTime[1]);

    endDate.setHours(endTime[0]);
    endDate.setMinutes(endTime[1]);

    let event = {
      name            : this.eventForm.controls.name.value,
      description     : this.eventForm.controls.description.value,
      place_id        : this.eventForm.controls.place_id.value,
      created_by      : this.eventForm.controls.created_by.value,
      type            : this.eventForm.controls.type.value,
      tag             : this.eventForm.controls.tag.value,
      organizers      : this.eventForm.controls.organizers.value,
      guests          : this.eventForm.controls.guests.value,
      resources       : this.eventForm.controls.resources.value,
      start_at        : this.datePipe.transform(startDate, 'y-MM-dd HH:mm:ss'),
      end_at          : this.datePipe.transform(endDate,   'y-MM-dd HH:mm:ss'),
      submitted       : true,
    };
    this.dialogRef.close(event);
  }

  validateStartDate(c: FormControl) {
    let currentDate = new Date();

    currentDate.setHours(0);
    currentDate.setMinutes(0);
    currentDate.setSeconds(0);
    currentDate.setMilliseconds(0);

    if(!(currentDate <= c.value)){
      return {startDate: {valid: false}};
    }
  }

  validateEndDate(c: FormControl) {
    let eventFormInputs = c.root;
    let startAt = eventFormInputs.get('start_at');

    if(startAt != null){
      if(startAt.value != null){
        if(startAt.value > c.value){
          return {startDateGreater: {valid: false}};
        }
      }else{
        return {startDateNull: {valid: false}};
      }
    }
  }

  validateStartDateTime(c: FormControl) {
    let eventFormInputs = c.root;
    let startAt        = eventFormInputs.get('start_at');
    

    if(startAt != null){
      if(startAt.value != null){
        let timeSelected  = (c.value).split(':');
        let currentDate   = new Date();

        startAt.value.setHours(timeSelected[0]);
        startAt.value.setMinutes(timeSelected[1]);

        if(!(currentDate <= startAt.value)){
          return {currentDateGreater: {valid: false}};
        }
      }else{
        return {startDateNull: {valid: false}};
      }
    }
  }

  validateEndDateTime(c: FormControl) {
    let eventFormInputs = c.root;
    let endAtDate       = eventFormInputs.get('end_at');
    let startAtDate     = eventFormInputs.get('start_at');
    let startAtTime     = eventFormInputs.get('start_at_time');

    if( (endAtDate != null) && (startAtDate != null) && ((startAtTime != null))){
      if(endAtDate.value != null){
        let timeSelected  = (c.value).split(':');
        let startTime     = (startAtTime.value).split(':');

        endAtDate.value.setHours(timeSelected[0]);
        endAtDate.value.setMinutes(timeSelected[1]);

        startAtDate.value.setHours(startTime[0]);
        startAtDate.value.setMinutes(startTime[1]);

        if(startAtDate.value >= endAtDate.value){
          return {startDateGreater: {valid: false}};
        }
      }else if(startAtTime.value === null){
        return {startTimeNull: {valid: false}};
      }else{
        return {endDateNull: {valid: false}};
      }
    }
  }

}

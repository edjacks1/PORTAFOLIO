import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { EventService } from '../../../../Services/Pages/eventService';
import { map } from 'rxjs/operators';



@Component({
  templateUrl: './checkResources.component.html',
  styleUrls: ['./checkResources.component.sass']
})

export class EventCheckResourcesFormComponent {
  resources: any;
  title = null;
  finalResource = [];
  error = false;

  constructor(private dialogRef: MatDialogRef<EventCheckResourcesFormComponent>,@Inject(MAT_DIALOG_DATA) public data, private eventService: EventService) {
    this.getEventResources(data);
  }

  getEventResources(event_id){
    this.eventService.getById(event_id).subscribe(resp => {
      this.resources = resp.data;
      this.title = resp.data.name;
    })
  }

  validate(){

    this.finalResource = [];

    this.resources.resources.forEach(element => {
      if(element.formEstatus === true){
        this.finalResource.push(element.resource_id);
      }
    });
    if(this.resources.resources.length === this.finalResource.length){
      let event = {
        resources    : this.finalResource,
        submitted    : true
      };
      this.dialogRef.close(event);
    }else{
      this.error = true;
    }
  }

  changeResourceAttribute(checkbox, index){
    if(checkbox.formEstatus){
      checkbox.formEstatus = false;
    }else{
      checkbox.formEstatus = true;
    }
    this.resources[index] = checkbox;
  }

}

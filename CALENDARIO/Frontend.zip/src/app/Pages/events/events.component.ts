import { Component } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RequestService } from '../../Services/request.service';

@Component({templateUrl: './events.component.html', providers: [DatePipe]})

export class EventsComponent {

  constructor(private datePipe: DatePipe, private requestService: RequestService){
    let date = new Date();

    let firstDay: any = new Date(date.getFullYear(), date.getMonth(), 1);
    let lastDay:  any = new Date(date.getFullYear(), date.getMonth() + 1, 0);

    let evento = {
      start_at : this.datePipe.transform(firstDay, 'y-MM-dd h:mm:ss'),
      end_at   : this.datePipe.transform(lastDay,  'y-MM-dd h:mm:ss')
    }
    console.log(evento);
    this.requestService.post('/event/getEvents',evento).subscribe(
      data  => {
        console.log(data);
      }
    );
  }

}

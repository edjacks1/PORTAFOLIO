import { Component } from '@angular/core';
import {FormControl, FormGroupDirective, NgForm, Validators, FormGroup} from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import { AuthService } from '../../Services/Pages/authService';


export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}


@Component({
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.sass']
})
export class LoginComponent {

  loginForm: FormGroup;
  matcher = new MyErrorStateMatcher();
  requestError = false;

  constructor(private authService: AuthService) {
    this.loginForm = new FormGroup({
      'password'          : new FormControl('',          [Validators.required,Validators.minLength(8)]),
      'email'             : new FormControl('',          [Validators.required,Validators.email]),
    });
  }

  validar(){
    let user = {
      email    : this.loginForm.controls.email.value,
      password : this.loginForm.controls.password.value,
    };

    this.authService.login(user).subscribe(
      data => {    
        localStorage.setItem('token',         data.data.token);
        localStorage.setItem('refresh_token', data.data.refresh_token);
        window.location.href = '/inicio';
      },
      error => {
        this.requestError = true;
      }
    );
  }


}

import { Component, ChangeDetectorRef, ViewChild } from '@angular/core';
//Material
import {MatPaginator      } from '@angular/material/paginator';
import {MatSort           } from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {MatDialog         } from '@angular/material/dialog';
//FormComponents
import { ResourceTypeGeneralFormComponent } from './forms/general/general.component';
//Services
import { TokenService        } from '../../Services/token.service';
import { ResourceTypeService } from '../../Services/Pages/resourceTypeService';
import { ToastrService       } from 'ngx-toastr';
//Configurations
import { toaster } from '../../Configurations/toaster';
//Interfaces
import { ResourceType } from '../../Interfaces/interfaces';

const TOASTER_OPTIONS = toaster;
const DIALOG_SIZE     = '500px';

@Component({templateUrl: './resourcesTypes.component.html'})

export class ResourcesTypesComponent{
  displayedColumns: string[] = ['id', 'name', 'description','options'];
  dataSource;

  currentUserPermissions:any;
  currentModulePermissions:any;

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  filterMatTableData(evento: Event) {
    const FILTER_VALUE = (evento.target as HTMLInputElement).value;
    this.dataSource.filter = FILTER_VALUE.trim().toLowerCase();
  }

  constructor(
                private chRef: ChangeDetectorRef,
                private tokenService: TokenService,
                private resourceTypeService: ResourceTypeService, 
                private dialog: MatDialog,
                private toastr: ToastrService
              ){ 
    this.listRT();
    this.userCan();
  }
  userCan(){
    this.currentUserPermissions   = this.tokenService.getPermissions();
    this.currentModulePermissions = {
      create_class : this.currentUserPermissions.includes("create_resourceType") ? '' : 'hidden' , 
      edit_class   : this.currentUserPermissions.includes("edit_resourceType")   ? '' : 'hidden' , 
      delete_class : this.currentUserPermissions.includes("delete_resourceType") ? '' : 'hidden' , 
      has_options  : (this.currentUserPermissions.includes("edit_resourceType") || this.currentUserPermissions.includes("delete_resourceType")) ? '' : 'hidden'
    }
  }
  listRT(){
    this.resourceTypeService.listAll().subscribe(resp => { 
      this.dataSource           = new MatTableDataSource<ResourceType>(resp.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort      = this.sort;
      this.chRef.detectChanges();
    });
  }
  addRT(resourceType = null){
    if(this.currentUserPermissions.includes("create_resourceType")){
      let dialogRef = this.dialog.open(ResourceTypeGeneralFormComponent,{
        data: resourceType === null ? '' : resourceType, 
        width: DIALOG_SIZE
      });
      dialogRef.afterClosed().subscribe((result: ResourceType) => {
        if(result['submitted']){
          this.resourceTypeService.store(result).subscribe(
            resp =>{
              this.listRT();
              this.toastr.success(`Se ha creado el tipo de recurso ${result.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.addRT(result); }
          );
        }
      });
    }
  }
  editRT(resourceType){
    if(this.currentUserPermissions.includes("edit_resourceType")){
      let dialogRef = this.dialog.open(ResourceTypeGeneralFormComponent,{data: resourceType, width: DIALOG_SIZE});
      dialogRef.afterClosed().subscribe((result: ResourceType) => {
        if(result['submitted']){
          this.resourceTypeService.update(resourceType.id,result).subscribe(
            resp =>{
              this.listRT();
              this.toastr.success(`Se ha editado el usuario ${resourceType.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.editRT(result); }
          );
        }
      });
    }
  }
  deleteRT(resourceType){
    if(this.currentUserPermissions.includes("delete_resourceType")){
      this.resourceTypeService.destroy(resourceType.id).subscribe(resp => {
        this.listRT();
        this.toastr.success(`Se ha eliminado el usuario ${resourceType.name}`, 'Exito',TOASTER_OPTIONS);
      })
    }
  }
}

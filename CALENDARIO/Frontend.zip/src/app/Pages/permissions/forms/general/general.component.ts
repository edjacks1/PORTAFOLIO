import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

import {FormControl,Validators, FormGroup} from '@angular/forms';
import { FormCustomErrorState } from '../../../../Components/formGroup/formCustomErrorState';


@Component({
  templateUrl: './general.component.html'
})
export class PermissionGeneralFormComponent{

  permissionForm: FormGroup;

  constructor(private dialogRef: MatDialogRef<PermissionGeneralFormComponent>,@Inject(MAT_DIALOG_DATA) private data) {
    this.permissionForm = new FormGroup({
      'name'              : new FormControl(data.name,                 [Validators.required]),
      'description'       : new FormControl(data.description,          [Validators.required]),
      'slug'              : new FormControl(data.slug,                 [Validators.required]),
    });
  }

  matcher = new FormCustomErrorState();


  validate(){
    let permission = {
      name                : this.permissionForm.controls.name.value,
      description         : this.permissionForm.controls.description.value,
      slug                : this.permissionForm.controls.slug.value,
      submitted           : true,
    };

    this.dialogRef.close(permission);
  }

}

import { Component, ChangeDetectorRef, ViewChild } from '@angular/core';
//Material
import {MatPaginator      } from '@angular/material/paginator';
import {MatSort           } from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
//Services
import { PermissionService } from '../../Services/Pages/permissionService';
//Interfaces
import { Permission } from '../../Interfaces/interfaces';

@Component({
  templateUrl: './permissions.component.html'
})
export class PermissionsComponent{

  displayedColumns: string[] = ['permission_id', 'name', 'description','slug'];
  dataSource;

  currentUserPermissions:any;
  currentModulePermissions:any;

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;


  constructor(private chRef: ChangeDetectorRef, private permissionService: PermissionService){
    this.listPermissions();
  }


  filterMatTableData(evento: Event) {
    const FILTER_VALUE = (evento.target as HTMLInputElement).value;
    this.dataSource.filter = FILTER_VALUE.trim().toLowerCase();
  }

  listPermissions(){
    this.permissionService.listAll().subscribe(resp => { 
      this.dataSource           = new MatTableDataSource<Permission>(resp.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort      = this.sort;
      this.chRef.detectChanges();
    });
  }
}

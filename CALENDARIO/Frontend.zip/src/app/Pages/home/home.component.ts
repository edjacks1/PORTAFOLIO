import { Component, ViewChild } from '@angular/core';
//FULL CALENDAR
import { CalendarOptions, FullCalendarComponent } from '@fullcalendar/angular';
import esLocale from '@fullcalendar/core/locales/es';
//MATERIAL
import { MatDialog } from '@angular/material/dialog';
//CONFIGURATIONS
import { DatePipe } from '@angular/common';
import { map      } from 'rxjs/operators';
import { toaster  } from '../../Configurations/toaster';
//FORMS
import { FormControl, FormGroup } from '@angular/forms';
import { EventGeneralFormComponent } from '../events/forms/general/general.component';
//SERVICES
import { TokenService     } from '../../Services/token.service';
import { UserService      } from '../../Services/Pages/userService';
import { EventTypeService } from 'src/app/Services/Pages/eventTypeService';
import { EventService     } from '../../Services/Pages/eventService';
import { ToastrService    } from 'ngx-toastr';

const TOASTER_OPTIONS = toaster;

@Component({templateUrl: './home.component.html',providers: [DatePipe]})
export class HomeComponent{
  fullCalendarEvents;
  calendarOptions: CalendarOptions;

  currentUserPermissions;
  currentModulePermissions;
 
  users;
  eventType;
  eventForm;

  @ViewChild('calendar') calendarComponent: FullCalendarComponent;

  constructor(
                private datePipe: DatePipe, 
                private tokenService: TokenService,
                private userService : UserService,
                private eventTypeService : EventTypeService,
                private eventService: EventService,
                private dialog: MatDialog,
                private toastr: ToastrService
              ) { 
    this.listUsers();
    this.listEventType();
    this.initFullCalendar(this.getCurrentDate());
    this.userCan();

    this.eventForm = new FormGroup({
      'organizer'        : new FormControl(null),
      'type'             : new FormControl(null),
    });
  }

  listUsers(){
    this.users = this.userService.listAll().pipe(map(data => { return data.data}));
  }
  listEventType(){
    this.eventType = this.eventTypeService.listAll().pipe(map(data => { return data.data}));
  }
  userCan(){
    this.currentUserPermissions   = this.tokenService.getPermissions();
    this.currentModulePermissions = {
      create_class : this.currentUserPermissions.includes("create_event") ? '' : 'hidden' , 
    }
  }
  addEvent(event = null){
    if(this.currentUserPermissions.includes("create_event")){
      let dialogRef = this.dialog.open(EventGeneralFormComponent,{data: event === null ? '' : event});
      dialogRef.afterClosed().subscribe((result) => {
        if(result['submitted']){
          this.eventService.store(result).subscribe(
            resp =>{
              this.initFullCalendar(this.getCurrentDate())
              this.toastr.success(`Se ha creado el evento ${result.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.addEvent(result); }
          );
        }
      });
    } 
  }
  initFullCalendar(eventData){
    this.eventService.listAll(eventData).subscribe(resp => {
      this.calendarOptions = {
        locale: esLocale,
          headerToolbar: { right: 'dayGridMonth,timeGridWeek,timeGrid', center: 'title', left: 'today prev,next' },
          buttonText:{
            today:         'Hoy',
            month:         'Mes',
            timeGridWeek:  'Semana',
            timeGrid:      'Día'
          },
          initialView: 'dayGridMonth',
          height: 800,
          // dateClick: this.handleDateClick.bind(this),
          // eventClick: this.displayEvent.bind(this),
          events: this.transformHttpResponse(resp.data) 
      };
    });

  }
  transformHttpResponse(response){
    return response.map(event => {
      return { 
        title:     event.name, 
        start:     event.start_at, 
        end:       event.end_at ,
        color:     event.tag.color,
        classNames: ['pointer'],
        // extendedProps: {
        //   id                : event.id,
        //   name              : event.name,
        //   description       : event.description,
        //   place_id          : event.place_id,
        //   start_at          : event.start_at,
        //   end_at            : event.end_at,
        //   created_by        : event.created_by,
        //   type              : event.type,
        //   guests            : event.guests,
        // }
      };
    });
  }
  filterData(){
    let eventData = this.getCurrentDate();
    let organizer = this.eventForm.controls.organizer.value;
    let type      = this.eventForm.controls.type.value;
    if(organizer != null){
      eventData['organizer'] = organizer;
    }
    if(type != null){
      eventData['type'] = type;
    }
    this.initFullCalendar(eventData);
  }

  getCurrentDate(){
    let date = new Date();
    let firstDay: any = new Date(date.getFullYear(), date.getMonth(), 1);
    let lastDay:  any = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    let eventDate = {
      start_at : this.datePipe.transform(firstDay, 'y-MM-dd HH:mm:ss'),
      end_at   : this.datePipe.transform(lastDay,  'y-MM-dd HH:mm:ss')
    }
    return eventDate;
  }

}

import { Component, Inject} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

import {FormControl, Validators, FormGroup} from '@angular/forms';
import { FormCustomErrorState } from '../../../../Components/formGroup/formCustomErrorState';


@Component({
  templateUrl: './general.component.html'
})
export class PlaceGeneralFormComponent {
  placeForm: FormGroup;

  constructor(private dialogRef: MatDialogRef<PlaceGeneralFormComponent>,@Inject(MAT_DIALOG_DATA) private data) {
    this.placeForm = new FormGroup({
      'name'              : new FormControl(data.name,          [Validators.required, Validators.maxLength(50)]),
      'description'       : new FormControl(data.description,   [Validators.required, Validators.maxLength(45)]),
      'x'                 : new FormControl(100,             [Validators.required]),
      'y'                 : new FormControl(100,             [Validators.required]),
    });
  }

  matcher = new FormCustomErrorState();

  validate(){
    let place = {
      name            : this.placeForm.controls.name.value,
      description     : this.placeForm.controls.description.value,
      x               : this.placeForm.controls.x.value,
      y               : this.placeForm.controls.y.value,
      submitted       : true
    };

    this.dialogRef.close(place);
  }

}

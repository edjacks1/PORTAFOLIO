import { Component, ChangeDetectorRef, ViewChild } from '@angular/core';
//Material
import {MatPaginator      } from '@angular/material/paginator';
import {MatSort           } from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {MatDialog         } from '@angular/material/dialog';
//FormComponents
import { PlaceGeneralFormComponent } from './forms/general/general.component';
//Services
import { TokenService  } from '../../Services/token.service';
import { PlaceService  } from '../../Services/Pages/placeService';
import { ToastrService } from 'ngx-toastr';
//Interface
import { Place } from '../../Interfaces/interfaces';
//Configurations
import { toaster } from '../../Configurations/toaster';

const TOASTER_OPTIONS = toaster;
const DIALOG_SIZE     = '500px';

@Component({
  templateUrl: './places.component.html'
})
export class PlacesComponent {

  displayedColumns: string[] = ['id','name','description','options'];
  dataSource;

  currentUserPermissions:any;
  currentModulePermissions:any;

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  constructor(
                private chRef: ChangeDetectorRef,
                private tokenService: TokenService,
                private placeService: PlaceService,
                private dialog: MatDialog,
                private toastr: ToastrService
              ) {
    this.listPlaces();
    this.userCan();
  }
  userCan(){
    this.currentUserPermissions   = this.tokenService.getPermissions();
    this.currentModulePermissions = {
      create_class : this.currentUserPermissions.includes("create_place") ? '' : 'hidden' , 
      edit_class   : this.currentUserPermissions.includes("edit_place")   ? '' : 'hidden' , 
      delete_class : this.currentUserPermissions.includes("delete_place") ? '' : 'hidden' , 
      has_options  : (this.currentUserPermissions.includes("edit_place") || this.currentUserPermissions.includes("delete_place")) ? '' : 'hidden'
    }
  }
  filterMatTableData(evento: Event) {
    const FILTER_VALUE = (evento.target as HTMLInputElement).value;
    this.dataSource.filter = FILTER_VALUE.trim().toLowerCase();
  }
  listPlaces(){
    this.placeService.listAll().subscribe(resp => { 
      this.dataSource           = new MatTableDataSource<Place>(resp.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort      = this.sort;
      this.chRef.detectChanges();
    });
  }
  addPlace(place = null){
    if(this.currentUserPermissions.includes("create_place")){
      let dialogRef = this.dialog.open(PlaceGeneralFormComponent,{data: place  === null ? '' : place, width: DIALOG_SIZE});
      dialogRef.afterClosed().subscribe((result : Place) => {
        if(result['submitted']){
          this.placeService.store(result).subscribe(
            resp =>{
              this.listPlaces();
              this.toastr.success(`Se ha creado el lugar ${result.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.addPlace(result); }
          );
        }
      });
    }
  }
  editPlace(place){
    if(this.currentUserPermissions.includes("edit_place")){
      let dialogRef = this.dialog.open(PlaceGeneralFormComponent,{data: place, width: DIALOG_SIZE});
      dialogRef.afterClosed().subscribe((result:Place) => {
        if(result['submitted']){
          this.placeService.update(place.id,result).subscribe(
            resp =>{
              this.listPlaces();
              this.toastr.success(`Se ha editado el lugar ${place.name}`, 'Exito',TOASTER_OPTIONS);
            },
            error =>{ this.editPlace(result); }
          );
        }
      });
    }
  }
  deletePlace(place){
    if(this.currentUserPermissions.includes("delete_place")){
      this.placeService.destroy(place.id).subscribe(resp => {
        this.listPlaces();
        this.toastr.success(`Se ha eliminado el usuario ${place.name}`, 'Exito',TOASTER_OPTIONS);
      });
    }
  }
}

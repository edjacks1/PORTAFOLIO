import { Component } from '@angular/core';
import { TokenService } from '../../../Services/token.service';

@Component({
  selector: 'dashboard-navegador',
  templateUrl: './navegador.component.html'
})
export class NavegadorComponent{

  permissions;

  constructor(tokenService: TokenService) { 
    let tokenPermissions = tokenService.getPermissions();;

    this.permissions = {
      users            : tokenPermissions.includes('see_user')         ,
      roles            : tokenPermissions.includes('see_role')         ,
      permissions      : tokenPermissions.includes('see_permission')   ,
      resources        : tokenPermissions.includes('see_resource')     ,
      organizations    : tokenPermissions.includes('see_organization') ,
      places           : tokenPermissions.includes('see_place')        ,
      resourcesTypes   : tokenPermissions.includes('see_resourceType') ,
      eventsTypes      : tokenPermissions.includes('see_eventType')    ,
      eventsTags       : tokenPermissions.includes('see_eventTag')     ,
    };
  }

}

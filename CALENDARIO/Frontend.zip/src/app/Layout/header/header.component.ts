import { Component } from '@angular/core';
//DIALOG
import {MatDialog} from '@angular/material/dialog';
//SERVICES
import { DatePipe     } from '@angular/common';
import { TokenService } from '../../Services/token.service';
import { ToastrService} from 'ngx-toastr';
//FORMCOMPONENT
import { EventCheckResourcesFormComponent } from '../../Pages/events/forms/checkResources/checkResources.component';
//CONFIGURATIONS
import { toaster } from '../../Configurations/toaster';
import { EventService } from '../../Services/Pages/eventService';

const TOASTER_OPTIONS = toaster;
const DIALOG_SIZE     = '500px';


@Component({
  selector: 'dashboard-header',
  templateUrl: './header.component.html',
  providers: [DatePipe]
})
export class HeaderComponent{

  openMenu;
  notifications = [];

  constructor(
                private datePipe: DatePipe, 
                private tokenService: TokenService,
                private eventService: EventService, 
                private dialog: MatDialog,
                private toastr: ToastrService
              ){
    this.checkForNotifications();
    if (window.innerWidth > 575) {
      this.openMenu = ((localStorage.getItem('openMenu') === null) ? ({
        'open': false
      }) : ({
        'open': JSON.parse(localStorage.getItem('openMenu'))['open']
      }));

      if ((localStorage.getItem('openMenu') != null)) {
        ((JSON.parse(localStorage.getItem('openMenu'))['open'] === true) ? (document.querySelector('app-root').classList.toggle('open')) : (''));
      }
    }
   }

  checkForNotifications() {
    this.notifications = [];
    this.eventService.listAll(this.getData()).subscribe(request => {
      request.data.forEach(element => {
        this.notifications.push({id : element.id, title: `Tienes un check list para el evento: ${element.name}`});
      });
    });             
  }
  getData(){
    let date = new Date();
    let eventData = {
      start_at        : this.datePipe.transform(date.setHours(0,0,0,0),     'y-MM-dd HH:mm:ss'),
      end_at          : this.datePipe.transform(date.setHours(23,59,59,59), 'y-MM-dd HH:mm:ss'),
      created_by      : this.tokenService.getUserId(),
      resources_check : 0,
      status          : 1
    }
    return eventData;
  }
  checkResourcesList(event_id){
    let dialogRef = this.dialog.open(EventCheckResourcesFormComponent,{data: event_id,width: DIALOG_SIZE});
    dialogRef.afterClosed().subscribe((result) => {
      if(result['submitted']){
        this.eventService.checkResources(event_id,result).subscribe(
          resp =>{
            this.checkForNotifications();
            this.toastr.success(`Se han validado los recursos`, 'Exito',TOASTER_OPTIONS);
          }
        );
      }
    });
  }
  logOut(){
    window.location.href = '/login';
  }
  toggleSideBar(){
    document.querySelector('app-root').classList.toggle('open');
    ((this.openMenu['open']) ? (this.openMenu['open'] = false) : (this.openMenu['open'] = true));
    localStorage.setItem('openMenu', JSON.stringify(this.openMenu));
  }
}

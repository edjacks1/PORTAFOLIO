import { Injectable } from '@angular/core';
import { HttpHeaders, HttpParams, HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { toaster } from '../Configurations/toaster';
import { AuthService } from '../Services/Pages/authService';

const TOASTER_OPTIONS = toaster;

@Injectable({providedIn: 'root'})

export class InterceptorService implements HttpInterceptor {

    token;

    constructor(private toastr: ToastrService, private authService: AuthService){
        this.token = localStorage.getItem('token');
    }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>{
        let direction = req.url.split('/');

        if(direction[direction.length -1] === 'login'){
            return next.handle(req);
        }else{
            if(this.token === '' || this.token === null){
                window.location.href = '/login';
            }else{
                const headers = new HttpHeaders({'authorization' : this.token});
                const request = req.clone({headers});

                return next.handle(request).pipe(
                  catchError((error: HttpErrorResponse) => { this.errorMessage(error); return throwError(error); })
                );
            }
        }
    }

    errorMessage(error: HttpErrorResponse){
        switch(error.status){
            case 400: 
                this.toastr.error(`${error.error.message}`, 'Error',TOASTER_OPTIONS); 
                break;
            case 403: 
                this.toastr.error('No tienes los permisos suficientes para esta acción.','Error',TOASTER_OPTIONS);
                break;
        }
        if(error.error.message === 'Provided token is expired.'){
            let refresh_token = {refresh_token : localStorage.getItem('refresh_token')};
            this.authService.refreshToken(refresh_token).subscribe(
                data => {this.renewToken(data);}
            );
        }
    }

    renewToken(data){
        this.token = data.token;

        localStorage.removeItem('token');
        localStorage.removeItem('refresh_token');

        localStorage.setItem('token',         data.token);
        localStorage.setItem('refresh_token', data.refresh_token);

        this.toastr.error('Su sessión ha expirado', 'Sessión expirada', {timeOut: 4000, progressBar: true});
        this.toastr.success('Porfavor vuelva a recargar la pagina','Se ha refrescado la sessión', {timeOut: 7000, progressBar: true});
    }
}

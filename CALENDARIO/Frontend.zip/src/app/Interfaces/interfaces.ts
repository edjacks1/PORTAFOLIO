export interface Response{
    data:   any;
    status: boolean;
}
export interface User {
    id:               number;
    name:             string;
    second_name:      string;
    last_name:        string;
    maternal_surname: string;
    email:            string;
    phone:            string;
    organization_id:  number;
    deleted_at:       null;
    created_at:       string;
    updated_at:       string;
    organization:     Organization;
    roles:            Roles[];
}

export interface Organization {
    id:           number;
    name:         string;
    abbreviation: string;
    phone:        string;
    email:        string;
    status:       number;
    x:            number;
    y:            number;
    created_at:   string;
    updated_at:   string;
    places:       Place[];
}

export interface Roles {
    user_has_role_id: number;
    user_id:          number;
    role_id:          number;
    role:             Role;
}

export interface Role {
    role_id:     number;
    name:        string;
    description: string;
    created_at:  string;
    updated_at:  string;
}

export interface Permission {
    permission_id: number;
    name:          string;
    slug:          string;
    description:   string;
}

export interface Place {
    id:          number;
    name:        string;
    x:           number;
    y:           number;
    description: string;
    status:      number;
}

export interface ResourceType {
    id:          number;
    name:        string;
    description: string;
    status:      number;
    created_at:  string;
    updated_at:  string;
}

export interface Resource {
    id:             number;
    owner:          number;
    patrimonial_id: string;
    type_id:        number;
    name:           string;
    description:    string;
    remark:         string;
    status:         number;
    created_at:     string;
    updated_at:     string;
}

export interface EventType {
    id:          number;
    name:        string;
    description: string;
    status:      number;
    created_at:  string;
    updated_at:  string;
}

export interface EventTag {
    id:     number;
    name:   string;
    color:  string;
    status: number;
}

import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TokenService } from '../Services/token.service';

@Injectable()
export class PermissionsGuard implements CanActivate{

    permissions: any;

    constructor(private tokenService: TokenService){
        this.permissions = this.tokenService.getPermissions();
    }
    
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
        let hasPermissions;

        switch(route['_routerState'].url){
            case '/usuarios'             : hasPermissions = this.permissions.includes('see_user');         break;
            case '/roles'                : hasPermissions = this.permissions.includes('see_role');         break;
            case '/permisos'             : hasPermissions = this.permissions.includes('see_permission');   break;
            case '/organizaciones'       : hasPermissions = this.permissions.includes('see_organization'); break;
            case '/lugares'              : hasPermissions = this.permissions.includes('see_place');        break;
            case '/recursos'             : hasPermissions = this.permissions.includes('see_resource');     break;
            case '/tipo_de_recursos'     : hasPermissions = this.permissions.includes('see_resourceType'); break;
            case '/tipo_de_evento'       : hasPermissions = this.permissions.includes('see_eventType');    break;
            case '/etiqueta_de_evento'   : hasPermissions = this.permissions.includes('see_eventTag');     break;
            default: hasPermissions = false; break
        }
        return hasPermissions;      
    }


}

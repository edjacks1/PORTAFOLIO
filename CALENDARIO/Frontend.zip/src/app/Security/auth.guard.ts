import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TokenService } from '../Services/token.service';
import { AuthService } from '../Services/Pages/authService';

@Injectable()
export class AuthGuard implements CanActivate{

    constructor(private authService: AuthService, private tokenService: TokenService) {
      
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {  
      if(this.tokenService.getExpirationStatus()){
        return true;
      }else{
        return this.checkTokenStatus();
      }
    }

    async checkTokenStatus(){
      let status = await new Promise<boolean>(resolve => {
        this.authService.validateToken({token: localStorage.getItem('token')}).subscribe(
          data  => {return resolve(true)},
          error => {
            localStorage.removeItem('token');
            localStorage.removeItem('refresh_token');
            localStorage.removeItem('permissions');
            window.location.href = '/login';
            return resolve(false);
          }
        );
      });
      return status
    }
}

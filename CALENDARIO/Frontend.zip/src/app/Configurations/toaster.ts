export const toaster = {
    timeOut: 3000,
    closeButton: true,
    progressBar: true
};
  
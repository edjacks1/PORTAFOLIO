import { Component, Input } from '@angular/core';

@Component({
  selector: 'dashboard-breadcrum-component',
  templateUrl: './breadcrum.component.html'
})
export class BreadcrumComponent {

  @Input('lists') lists;

  constructor() { }
}

import { AsyncValidator, AbstractControl, ValidationErrors, NG_ASYNC_VALIDATORS } from '@angular/forms';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Directive, Input } from '@angular/core';
import { UserService } from '../../Services/Pages/userService';

@Directive({
    selector: '[uniqueEmail]',
    providers: [{provide: NG_ASYNC_VALIDATORS, useExisting: UniqueEmailValidator, multi: true}]
})

export class UniqueEmailValidator implements AsyncValidator{

    @Input('uniqueEmail') id: string;

    constructor(private userService: UserService){}

    validate(control: AbstractControl): Promise<ValidationErrors | null> | Observable<ValidationErrors | null> {
        let user = {email: control.value, id: this.id};

        return this.userService.checkEmail(user).pipe(map((users:any)=>{
            return users.message === 'Email is already taken' ? {uniqueEmail: true} : null;
        }));
    }

}
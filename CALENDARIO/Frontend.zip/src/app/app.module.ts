import { NgModule                            } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserModule                       } from '@angular/platform-browser';
import { BrowserAnimationsModule             } from '@angular/platform-browser/animations';
//FORMS
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { UniqueEmailValidator            } from './Components/formGroup/validateUniqueEmail';
//MATERIAL
import { MatTableModule    }    from '@angular/material/table';
import { MatPaginatorModule}    from '@angular/material/paginator';
import { MatSortModule     }    from '@angular/material/sort';
import { MatInputModule    }    from '@angular/material/input';
import { MatIconModule     }    from '@angular/material/icon';
import { MatSelectModule   }    from '@angular/material/select';
import { MatDialogModule   }    from '@angular/material/dialog';
import { MatButtonModule   }    from '@angular/material/button';
import { MatTooltipModule  }    from '@angular/material/tooltip';
import { MatCardModule     }    from '@angular/material/card';
import { MatMenuModule     }    from '@angular/material/menu';
import { MatDividerModule  }    from '@angular/material/divider';
import { MatListModule     }    from '@angular/material/list';
import { MatCheckboxModule }    from '@angular/material/checkbox';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material';
//TOASTER
import { ToastrModule } from 'ngx-toastr';
//COLOR PICKER
import { ColorPickerModule } from '@syncfusion/ej2-angular-inputs';
import { enableRipple      } from '@syncfusion/ej2-base';
//FULL CALENDAR
import { FullCalendarModule } from '@fullcalendar/angular'; 
import dayGridPlugin          from '@fullcalendar/daygrid'; 
import interactionPlugin      from '@fullcalendar/interaction'; 
import timeGridPlugin         from '@fullcalendar/timegrid';
//SERVICES
import { InterceptorService   } from './Interceptors/interceptor.service';
//GUARDS
import { AuthGuard            } from './Security/auth.guard';
import { PermissionsGuard     } from './Security/permissions.guard';
//LAYOUT
import { NavegadorComponent } from './Layout/Sidebar/navegador/navegador.component';
import { HeaderComponent    } from './Layout/header/header.component';
import { BreadcrumComponent } from './Components/breadcrum/breadcrum.component';
//COMPONENTS
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
//LOGIN COMPONENTS
import { LoginComponent } from './Pages/login/login.component';
//USER COMPONENTS
import { UsersComponent                 } from './Pages/users/users.component';
import { UserGeneralFormComponent       } from './Pages/users/forms/general/general.component';
import { UserAssignRolesFormComponent   } from './Pages/users/forms/assignRoles/assignRoles.component';
import { UserShowAssignedRolesComponent } from './Pages/users/show/roles/assignedRoles.component';
//ROLES COMPONENTS
import { RolesComponent                       } from './Pages/roles/roles.component';
import { RoleAssignPermissionsFormComponent   } from './Pages/roles/forms/assignPermissions/assignPermissions.component';
import { RoleGeneralFormComponent             } from './Pages/roles/forms/general/general.component';
import { RoleShowAssignedPermissionsComponent } from './Pages/roles/show/assignedPermissions/assignedPermissions.component';
//PERMISSIONS COMPONENTS
import { PermissionsComponent           } from './Pages/permissions/permissions.component';
import { PermissionGeneralFormComponent } from './Pages/permissions/forms/general/general.component';
//ORGANIZATIONS COMPONENTS
import { OrganizationsComponent                  } from './Pages/organizations/organizations.component';
import { OrganizationGeneralFormComponent        } from './Pages/organizations/forms/general/general.component';
import { OrganizationAssignPlacesFormComponent   } from './Pages/organizations/forms/assignPlaces/assignPlaces.component';
import { OrganizationShowAssignedPlacesComponent } from './Pages/organizations/show/assignedPlaces/assignedPlaces.component';
//PLACES COMPONENTS
import { PlacesComponent           } from './Pages/places/places.component';
import { PlaceGeneralFormComponent } from './Pages/places/forms/general/general.component';
//RESOURCES COMPONENTS
import { ResourcesComponent               } from './Pages/resources/resources.component';
import { ResourceGeneralFormComponent     } from './Pages/resources/forms/general/general.component';
import { ResourcesTypesComponent          } from './Pages/resourcesTypes/resourcesTypes.component';
import { ResourceTypeGeneralFormComponent } from './Pages/resourcesTypes/forms/general/general.component';
//EVENTS COMPONENTS
import { HomeComponent                    } from './Pages/home/home.component';
import { EventGeneralFormComponent        } from './Pages/events/forms/general/general.component';
import { EventCheckResourcesFormComponent } from './Pages/events/forms/checkResources/checkResources.component';
import { EventsTypesComponent             } from './Pages/eventsTypes/eventsTypes.component';
import { EventTypeGeneralFormComponent    } from './Pages/eventsTypes/forms/general/general.component';
import { EventsTagsComponent              } from './Pages/eventsTags/eventsTags.component';
import { EventTagGeneralFormComponent     } from './Pages/eventsTags/forms/general/general.component';



enableRipple(true);

FullCalendarModule.registerPlugins([
  dayGridPlugin,
  interactionPlugin,
  timeGridPlugin
]);


@NgModule({
  declarations: [
    AppComponent,
    UniqueEmailValidator,
    //LAYOUT
    NavegadorComponent,
    HeaderComponent,
    BreadcrumComponent,
    //LOGIN
    LoginComponent,
    //PERMISSIONS
    PermissionsComponent,
    PermissionGeneralFormComponent,
    //ORGANIZATIONS
    OrganizationsComponent,
    OrganizationGeneralFormComponent,
    OrganizationAssignPlacesFormComponent,
    OrganizationShowAssignedPlacesComponent,
    //PLACES
    PlacesComponent,
    PlaceGeneralFormComponent,
    //USERS
    UsersComponent,
    UserShowAssignedRolesComponent,
    UserAssignRolesFormComponent,
    UserGeneralFormComponent,
    //ROLES
    RolesComponent,
    RoleGeneralFormComponent,
    RoleAssignPermissionsFormComponent,
    RoleShowAssignedPermissionsComponent,
    //RESOURCES
    ResourcesComponent,
    ResourceGeneralFormComponent,
    ResourcesTypesComponent,
    ResourceTypeGeneralFormComponent,
    //EVENTS
    HomeComponent,
    EventGeneralFormComponent,
    EventCheckResourcesFormComponent,
    EventsTypesComponent,
    EventTypeGeneralFormComponent,
    EventsTagsComponent,
    EventTagGeneralFormComponent
    // EventosComponent
  ],
  imports: [
    FullCalendarModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatInputModule,
    MatIconModule,
    MatSelectModule,
    MatDialogModule,
    MatButtonModule,
    MatTooltipModule,
    MatCardModule,
    MatMenuModule,
    MatDividerModule,
    MatListModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatNativeDateModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ColorPickerModule,
    ToastrModule.forRoot(),
  ],
  providers: [
    {provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true},
    AuthGuard,PermissionsGuard
  ],
  bootstrap: [AppComponent],
  entryComponents: [
    UserGeneralFormComponent,
    UserAssignRolesFormComponent,
    UserShowAssignedRolesComponent,

    OrganizationGeneralFormComponent,
    OrganizationAssignPlacesFormComponent,
    OrganizationShowAssignedPlacesComponent,

    PlaceGeneralFormComponent,
    PermissionGeneralFormComponent,

    ResourceGeneralFormComponent,
    ResourceTypeGeneralFormComponent,
    
    RoleGeneralFormComponent,
    RoleAssignPermissionsFormComponent,
    RoleShowAssignedPermissionsComponent,
    
    EventGeneralFormComponent,
    EventCheckResourcesFormComponent,

    EventTypeGeneralFormComponent,
    EventTagGeneralFormComponent
  ]
})
export class AppModule { }
